# Anti Drift Prompting

Prompt phrases that force lace structure instead of printed texture.

## Diagnostic questions

- Are there real holes or only printed shapes?
- Are thread paths visible?
- Is there motif hierarchy?
- Is there a ground structure?
- Are edges specified?
- Does the lace family make sense?
- Is the material believable?

## Repair prompt

```text
make the lace structurally open, with visible thread paths, transparent voids, motif-and-ground hierarchy, tiny cast shadows, and construction logic; avoid flat printed floral fabric
```
